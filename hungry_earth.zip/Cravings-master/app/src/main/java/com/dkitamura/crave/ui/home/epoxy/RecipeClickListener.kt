package com.dkitamura.crave.ui.home.epoxy

interface RecipeClickListener {

    fun onRecipeClicked(id: Int)
}