package com.dkitamura.crave.ui.test

import androidx.lifecycle.ViewModel

class TestViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}